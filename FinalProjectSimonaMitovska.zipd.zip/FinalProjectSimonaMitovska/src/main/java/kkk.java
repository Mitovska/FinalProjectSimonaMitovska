import java.util.Arrays;

public class kkk {
    public static void main(String[] args) {

        String[] Months = new String[5];
        Months[0] = "January";
        Months[1] = "February";
        Months[2] = "March";
        Months[3] = "Aprill";
        Months[4] = "May";

     PrintAllMonths(Months);

        double [] dNum = {2.4,4.5,6.8,7.1,11.2};
        SumAllNum(dNum);

        TretaZadaca();

        int [] field = {2, 20, 3, 13, 15, 3, 9, 10, 1, 5, 8};
        System.out.println(CountOddNumbers(field));


    }

    public static void PrintAllMonths(String[] parametar){
        int i = 0;
        while( i < Arrays.stream(parametar).count()){
            System.out.println(parametar[i]);
            i++;
        }

    }

    public static void SumAllNum(double[] parametar){
        double result = 0;
        for(int i = 0; i < Arrays.stream(parametar).count(); i++) {
            result += parametar[i];
        }
        System.out.println(result);
        System.out.println(result / Arrays.stream(parametar).count());

    }
    public static void TretaZadaca(){
        int [] Lista = new int[20];
        for(int i = 0; i <= 19; i++){
            Lista[i] = i+1;
        }
        for(int i = 19; i >= 0; i--){
            System.out.println(Lista[i]);
        }

    }
    public static Integer CountOddNumbers(int[] parametar){
        int count = 0;
        for(int i = 0; i < Arrays.stream(parametar).count(); i++){
            if(parametar[i] %2 == 1){
                count += 1;
            }
        }
        return count;
    }

}



