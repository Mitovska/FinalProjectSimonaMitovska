package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seleniumhq.jetty9.util.log.Log;

import java.util.List;

public class MagentoPage {
    WebDriver driver;
    WebDriverWait wait;
    By CreateAnAccountField = By.xpath("//div[@class='panel header']/ul/li[3]/a");
    By FirstNameField = By.xpath("//input[@id='firstname' and @title='First Name']");
    By LastNameField = By.id("lastname");
    By SignUpForNewsletter = By.id("is_subscribed");
    By EmailField = By.id("email_address");
    By PasswordField = By.id("password");
    By ConfirmPasswordField = By.id("password-confirmation");
    By CreateAnAccField = By.xpath("//div[@class='actions-toolbar']/div[@class='primary']/button/span");
    By MenButton = By.xpath("//a[@id='ui-id-5']/span[2]");
    By clickProductItem = By.xpath("//a[@title='Hero Hoodie']");
    By clickAddToCartButton = By.xpath("//button[@id='product-addtocart-button']/span");
    By ProductColor = By.xpath("//div[@id='option-label-color-93-item-53']");
    By ProductSize = By.xpath("//div[@id='option-label-size-143-item-168']");
    By ProductQuantity = By.xpath("//input[@id='qty']");
    By clickWomenButton = By.xpath("//a[@id='ui-id-4']/span[2]");
    By clickProductItem2 = By.xpath("//a[@title='Breathe-Easy Tank']");
    By ProductColor2=By.xpath("//div[@id='option-label-color-93-item-57']");
    By ProductSize2=By.xpath("//div[@id='option-label-size-143-item-167']");
    By ProductQuantity2 = By.xpath("//input[@id='qty']");
    By ShoppingCartButton= By.xpath("//a[@class='action showcart']");
    By ProceedToCheckout = By.xpath("//*[@id='top-cart-btn-checkout']");
    By shippingCompany = By.xpath("//div[@name='shippingAddress.company']/div/input");
    By shippingStreetAddress = By.xpath("//div[@name='shippingAddress.street.0']/div/input");
    By shippingCity = By.xpath("//div[@name='shippingAddress.city']/div/input");
    By ShippingState= By.xpath("//div[@name='shippingAddress.region_id']/div/select");
    By shippingPostalCode = By.xpath("//div[@name='shippingAddress.postcode']/div/input");
    By shippingPhoneNumber = By.xpath("//div[@name='shippingAddress.telephone']/div/input");
    By clickShippingNextButton = By.xpath("//button[@class='button action continue primary']/span");
    By ShippingMethodsRadioButton = By.xpath("//td[@class='col col-method']/input");
    By clickPageLogo = By.xpath("//a[@class='logo']/img");
    By productName = By.xpath("//span[@class='base']");
    By clickHomepageButton=By.xpath("//a[@title='Go to Home Page']");
    By SearchBarField = By.xpath("//input[@id='search']");
    By clickSaleCategory = By.xpath("//a[@id='ui-id-8']/span");
    By clickCustomerServiceField= By.xpath("//div/div/ul/li[2]/a");
    By clickContactUsField = By.xpath("//ul[@class='footer links']/li[4]/a");
    By clickSignOutButton = By.xpath("//body/div[1]/header/div[1]/div/ul/li[2]/div/ul/li[3]/a");
    By clickMyAccountButton = By.xpath("//body/div[1]/header/div[1]/div/ul/li[2]/div/ul/li[1]/a");
    By clickForgotYourPasswordButton = By.xpath("//div/div[2]/a[@class='action remind']/span");
    By DefaultWelcomeMessage = By.xpath("//body/div[1]/header/div[1]/div/ul/li[1]/span");
    By clickChangePassword = By.xpath("//a[@class='action change-password']");
    By clickDropdownButton = By.xpath("//div[@class='panel header']/ul/li[2]/span/button");
    By currentPasswordField = By.xpath("//input[@id='current-password']");
    By newPasswordField = By.xpath("//input[@data-input='new-password']");
    By confirmPasswordField = By.xpath("//input[@id='password-confirmation']");
    By clickSaveButton = By.xpath("//div[@class='actions-toolbar']/div/button[@title='Save']/span");
    By logInEmail = By.xpath("//input[@name='login[username]']");
    By logInPassword = By.xpath("//input[@name='login[password]']");
    By clickSignInButton =By.xpath("//button[@class='action login primary']/span");
    By SavedAccountInformation = By.xpath("//div[@class='message-success success message']/div");
    By AddedProductToCartMessage= By.xpath("//div[@class='message-success success message']/div");
    By PasswordStrengthMessage=By.xpath("//span[@id='password-strength-meter-label']");
    By RegisteringMessage = By.xpath("//div[@class='message-success success message']/div");
    By ShoppingCartCount = By.xpath("//body/div[1]/header/div[2]/div[1]/div/div/div/div[2]/div[1]/span[1]");
    By clearQuantityField = By.xpath("//input[@id='qty']");
    By PageTitle = By.xpath("//h1[@class='page-title']/span");
    By PersonalInformationTitle = By.xpath("//fieldset[@class='fieldset create info']/legend/span");
    By SalePictureContent=By.xpath("//a[@class='block-promo sale-main']/img");
    By CartSubtotal = By.xpath("//div[@class='amount price-container']/span/span");
    By ViewAndEditCartText= By.xpath("//a[@class='action viewcart']/span");
    By clickPlaceOrderButton = By.xpath("//*[contains(@class='action primary')] ");
    By OrderSummary = By.xpath("//*[@class='opc-block-summary']");
    By PurchaseMessage = By.xpath("//*[@class='base']");
    By CheckoutSuccess = By.xpath("//*[@class='checkout-success']");
    By EditShippingAddress = By.xpath("//div[@class='box box-shipping-address']/div/a");




    public MagentoPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;


    }

    public void navigateToPage(String url) {
        driver.get(url);
    }
    public void clickSaleCategory(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickSaleCategory)).click();
    }
    public void findDefaultWelcomeMessage(){
        wait.until(ExpectedConditions.presenceOfElementLocated(DefaultWelcomeMessage)).isDisplayed();
    }

    public void clickShoppingCartButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ShoppingCartButton)).click();
    }
    public void clickProceedToCheckout(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProceedToCheckout)).click();
    }
    public void clickEditShippingAddress(){
        wait.until(ExpectedConditions.presenceOfElementLocated(EditShippingAddress)).click();
    }
    public void clickPlaceOrderButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickPlaceOrderButton)).click();
    }
    public void findCheckoutSuccess(){
        wait.until(ExpectedConditions.presenceOfElementLocated(CheckoutSuccess)).isDisplayed();
    }
    public void findOrderSummary(){
        wait.until(ExpectedConditions.presenceOfElementLocated(OrderSummary)).isDisplayed();
    }
    public String findShoppingCartCount(){
      return wait.until(ExpectedConditions.presenceOfElementLocated(ShoppingCartCount)).getText();
    }
    public String findViewAndEditCartText(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(ViewAndEditCartText)).getText();
    }
    public String findPurchaseMessage(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(PurchaseMessage)).getText();
    }
    public String findCartSubtotal(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(CartSubtotal)).getText();
    }
    public void findSalePictureContent(){
         wait.until(ExpectedConditions.presenceOfElementLocated(SalePictureContent)).isDisplayed();
    }
    public String findPageTitle(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(PageTitle)).getText();
    }
    public String findPersonalInformationTitle(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(PersonalInformationTitle)).getText();
    }
    public void clearQuantityField(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clearQuantityField)).clear();
    }
    public void logInEmail(String LogInEmail){
        wait.until(ExpectedConditions.presenceOfElementLocated(logInEmail)).sendKeys(LogInEmail);
    }
    public String returnPasswordStrengthMessage(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(PasswordStrengthMessage)).getText();
    }
    public String returnRegisteringMessage(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(RegisteringMessage)).getText();
    }
    public void logInPassword(String LogInPassword){
        wait.until(ExpectedConditions.presenceOfElementLocated(logInPassword)).sendKeys(LogInPassword);

    }
    public void ClickDropdownButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickDropdownButton)).click();
    }
    public String returnSavedAccountInformation(){
        return wait.until(ExpectedConditions.presenceOfElementLocated(SavedAccountInformation)).getText();
    }
    public String returnAddedProductToCartMessage() {
       return wait.until(ExpectedConditions.presenceOfElementLocated(AddedProductToCartMessage)).getText();
    }
    public void clickSignInButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickSignInButton)).click();
    }
    public void clickSaveButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickSaveButton)).click();
    }
    public void currentPasswordField(String currentPassword){
        wait.until(ExpectedConditions.presenceOfElementLocated(currentPasswordField)).sendKeys(currentPassword);
    }
    public void newPasswordField(String newPassword){
        wait.until(ExpectedConditions.presenceOfElementLocated(newPasswordField)).sendKeys(newPassword);
    }
    public void confirmPasswordField(String ConfirmPasswordField){
        wait.until(ExpectedConditions.presenceOfElementLocated(confirmPasswordField)).sendKeys(ConfirmPasswordField);
    }
   public void clickChangePassword(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickChangePassword)).click();
    }
    public void clickForgotYourPasswordButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickForgotYourPasswordButton)).click();
    }
    public void clickCustomerServiceField(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickCustomerServiceField)).click();
    }
    public void clickContactUsField(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickContactUsField)).click();
    }
    public void clickSignOutButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickSignOutButton)).click();
    }
    public void clickMyAccountButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickMyAccountButton)).click();
    }
    public void SearchBarField(String searchBar){
        wait.until(ExpectedConditions.presenceOfElementLocated(SearchBarField)).sendKeys(searchBar);
    }
    public String returnProductName(){
       return wait.until(ExpectedConditions.presenceOfElementLocated(productName)).getText();
    }
    public void clickHomepageButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickHomepageButton)).click();
    }
    public void clickCreateAnAccountField() {
       wait.until(ExpectedConditions.presenceOfElementLocated(CreateAnAccountField)).click();

    }
   public void selectShippingState(int index){
        wait.until(ExpectedConditions.presenceOfElementLocated(ShippingState)).click();
        List<WebElement>list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ShippingState));
        list.get(index).click();
    }
    public void clickShippingRadioButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ShippingMethodsRadioButton)).click();
    }
    public void clickPageLogo(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickPageLogo)).click();
    }
    public void clickShippingNextButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickShippingNextButton)).click();
    }
    public void shippingCompany(String ShippingCompany){
        wait.until(ExpectedConditions.presenceOfElementLocated(shippingCompany)).sendKeys(ShippingCompany);
    }
    public void shippingPhoneNumber(String ShippingPhoneNumber){
        wait.until(ExpectedConditions.presenceOfElementLocated(shippingPhoneNumber)).sendKeys(ShippingPhoneNumber);
    }
    public void ShippingState(){
         wait.until(ExpectedConditions.presenceOfElementLocated(ShippingState)).sendKeys("Alaska");
    }
    public void shippingStreetAddress(String ShippingStreetAddress){
        wait.until(ExpectedConditions.presenceOfElementLocated(shippingStreetAddress)).sendKeys(ShippingStreetAddress);
    }
    public void shippingCity(String ShippingCity) {
        wait.until(ExpectedConditions.presenceOfElementLocated(shippingCity)).sendKeys(ShippingCity);
    }
    public void shippingPostalCode(String ShippingPostalCode) {
        wait.until(ExpectedConditions.presenceOfElementLocated(shippingPostalCode)).sendKeys(ShippingPostalCode);
    }
    public void clickProductColor(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductColor)).click();
    }

    public void clickWomenButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickWomenButton)).click();
    }
    public void clickProductItem2(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickProductItem2)).click();
    }
    public void clickProductColor2(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductColor2)).click();
    }
    public void clickProductSize(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductSize)).click();
    }
    public void clickProductSize2() {
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductSize2)).click();
    }
    public void ProductQuantity(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductQuantity)).sendKeys("2");
    }
    public void ProductQuantity2(){
        wait.until(ExpectedConditions.presenceOfElementLocated(ProductQuantity2)).sendKeys("3");
    }
    public void clickAddToCartButton(){
        wait.until(ExpectedConditions.presenceOfElementLocated(clickAddToCartButton)).click();
    }

    public void clickProductItem() {
        wait.until(ExpectedConditions.presenceOfElementLocated(clickProductItem)).click();
    }

    public void clickMenButton() {
        wait.until(ExpectedConditions.presenceOfElementLocated(MenButton)).click();
    }

    public void enterFirstNameField(String firstname) {
        wait.until(ExpectedConditions.presenceOfElementLocated(FirstNameField)).sendKeys(firstname);
    }

    public void enterLastNameField(String lastname) {
        wait.until(ExpectedConditions.presenceOfElementLocated(LastNameField)).sendKeys(lastname);
    }

    public void clickSignUpForNewsletter() {
        wait.until(ExpectedConditions.presenceOfElementLocated(SignUpForNewsletter)).click();

    }
    public void enterEmailField(String email){
        wait.until(ExpectedConditions.presenceOfElementLocated(EmailField)).sendKeys(email);

    }
    public void enterPasswordField(String password){
        wait.until(ExpectedConditions.presenceOfElementLocated(PasswordField)).sendKeys(password);

    }
    public void enterConfirmPasswordField(String confirmPassword){
        wait.until(ExpectedConditions.presenceOfElementLocated(ConfirmPasswordField)).sendKeys(confirmPassword);
    }
    public void clickCreateAnAccField() {
        wait.until(ExpectedConditions.presenceOfElementLocated(CreateAnAccField)).click();

}}
